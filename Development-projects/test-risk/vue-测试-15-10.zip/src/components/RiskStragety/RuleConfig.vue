<template>
	<div id="ruleConfig" v-if="action">
		<!-- headr ber-->
		<header class="addRulesBtnBox">
			<add-button v-show="String(action) == 'true'" :params="{val:'新增规则+',name:'create-rule',action:'create'}" ></add-button>
			<back v-show="String(action) != 'true'" :params="{name:action,modalShow:''}" @edit="editable" ></back>
			<div class="rule-search">
				<input type="text" id="rule-search" placeholder="请输入规则名" value="" v-model="pageData.searchField"/>
				<div class="rule-search-but" >Search</div>
			</div>
		</header>
		<section class="tableContainer">
			<!-- 规则列表tab -->
			<div class="tableBox">
				<table border="" class="rule-tab">
					<tr>
						<th>操作</th>
						<th v-for="(item,key) in pageData.rule_thead">{{item}}</th>
					</tr>
					<tr v-for="(row,index) in pageData.rule_data" @dblclick="viewRuleDetails(row)">
						<td class="rule-tools">
							<rule-toolber v-on:rule-action="ruleAction" :params="{'name':$route.query.action,'id':$route.query.id,'values':row}"></rule-toolber>
						</td>
						<td v-for="(item,key) in pageData.rule_thead" v-if="key == 'desc'" v-html="row[key]"></td>
						<td v-else>{{row[key]}}</td>
					</tr>
				</table>
			</div>
			<!-- 要添加到的规则集列表  -->
			<div class="addToRuleset-wrap" v-show="ruleset_list_show">
				<p class="ruleset-name">规则集名</p>
				<section class="addToRuleset-main">
					<ul class="ruleset-items">
						<li class="ruleset-item" v-for="row in pageData.not_associated_data" @click="selected.ruleset_id = row.id">
							{{row.group_name}}
							<svg-icon id="icon-2xuanzhong" style="color: green;"  v-show="row.id == selected.ruleset_id"></svg-icon>
						</li>
					</ul>
				</section>
				<p class="addRule-confirm">
					<span class="confirm-cancel confirm-tiem" @click="addRuleset(0)">取消</span>
					<span class="confirm-add confirm-tiem" @click="addRuleset(1)">确定</span>
				</p>
			</div>
		</section>
		<!-- 规则详情 -->
		<rule-details ref="rulesDetails" v-show="rules_details_show"></rule-details>
		<!-- 新增规则 -->
		<router-view></router-view>
	</div>
</template>

<script type="text/ecmascript-6">
	import RuleToolber		from "./../common/rule-config-modules/rule-toolber.vue"// 规则工具栏
	import RuleDetails		from "./../common/rule-config-modules/rule-details.vue" // 规则详情
	export default {
		name: 'ruleConfig',
		data() {
			return {
				action:false, // view渲染开关
				response_status:false,// 异步请求响应状态
				rules_details_show:false, // 规则详情渲染
				ruleset_list_show:false, //  可添加规则集列表
				selected:{
					rule_id:-1,  // 选中的 可添加规则 id
					ruleset_id:-1// 选中的 可添加规则集 id
				},
				pageData:{
					rule_data:[],
					associated_data:[],
					not_associated_data:[],
					searchField:'', // 搜索字段
					rule_thead: {
						"id": "规则ID",
						"rule_name": "规则编号",
						"desc": "规则内容",
						"approve_action": "执行动作",
						"threshold": "参数"
					}
				}
			}
		},
		watch:{
			response_status(curVal,oldVal){
				if(curVal.code == 1){
					// 所有规则数据
					if(curVal.name == 'rule'){
						this.pageData.rule_data = curVal.message;
						this.action = true;
					}
					// 关联规则集数据
					if(curVal.name == 'associated'){
						this.$refs.rulesDetails.pageData.correlation.values = curVal.message;
					}
					// 未关联规则集数据
					if(curVal.name == 'notAssociated'){
						this.pageData.not_associated_data = curVal.message;
						this.ruleset_list_show = true;
					}
					if(curVal.name == 'addRuleset'){
						alert("添加成功");
						this.ready();
					}
				}else{
					if(curVal.name == 'rule'){
						alert("规则 数据请求失败！");
					}
					if(curVal.name == 'ruleset'){
						alert("规则集 数据请求失败！");
					}
					if(curVal.name == 'associated'){
						alert("关联 数据请求失败！");
					}
				}
			},
			$route(curVal,oldVal){
				console.log(curVal,oldVal)
			}
		},
		mounted(){
			this.ready();
		},
		components:{
			"rule-toolber":RuleToolber,
			"rule-details":RuleDetails
		},
		methods: {
			ready(){
				// 规则全部数据
				this.sendRequest(this,'/rule/ruleGoodsCatagory?select_rows={}','response_status',"rule");
				// （创建规则集||规则集详情）页面跳转进来的，不需要请求关联表&规则集表
				if(this.$route.query.action == 'create' || this.$route.query.action == 'append'){
					this.fullPath = this.$route.fullPath;// 记录当前url
				}
			},
			ruleAction(msg){
				if(msg.action == 'list'){// 添加到指定规则集,显示规则集列表 
					this.sendRequest(this,'/rule/ruleGoodsCatagory?select_rows={"notAssociated":'+msg.id+'}','response_status',"notAssociated");
					this.selected.rule_id = msg.id;
					this.selected.ruleset_id  = -1;
				}
				if(msg.action == 'modify'){// 修改数据
					this.$router.push({
                        path:"/riskStrategy/ruleConfig/create-rule",
                        query:{action:'modify',id:msg.id}
                    });
				}
			},
			viewRuleDetails(msg){// 双击查看规则集详情
				// 查询关联数据
				this.sendRequest(this,'/rule/ruleGoodsCatagory?select_rows={"associated":'+msg.id+'}','response_status',"associated");
				this.$refs.rulesDetails.pageData.values.map((row,i) => {
					if(msg[row.field] != undefined){
						row.val = msg[row.field];
					}
				});
				this.rules_details_show = true;
			},
			addRuleset(msg){// 添加到规则集操作
				if(msg && this.selected.group_id > -1){ // 确认 
					if(this.pageData.associationRulesetList.selectedRuleSet.group_id){
						var updata  = {
								"rule_count"	 : this.pageData.associationRulesetList.selectedRuleSet.associationRule_id.length,
								"associative_arr": [
									{	id:this.pageData.associationRulesetList.selectedRule_id,
										state:'0'
									}
								],
								"ruleset_id": this.pageData.associationRulesetList.selectedRuleSet.group_id // 当前规则集id
							};
						this.sendRequest(this,'/rule/ruleGoodsCatagory?update_rows='+JSON.stringify(updata),'response',"addRuleset");
					}
				}
				this.ruleset_list_show = false;
			},
			formatInitialData(arr){
				for(let i = 0;i < arr.length; i++){
					if(!arr[i].enabled){
						arr[i]['revisability'] = true;
					}
				}
			}
		}
	}
</script>

<style lang="less" type="text/less">
	@import url("./../../less/common");
	#ruleConfig{ 
		position:relative; 
		padding:15px 10px 15px 15px;
		width:100%;
		height:100%;
		border-radius:5px; 
		background:#fff; 
		.addRulesBtnBox{ 
			width:100%;
			height:6%;
			.rule-search{
				width: 300px;
				float: right;
				font-size: 0;
				text-align: right;
				#rule-search{
					width: 200px;
					padding: 5px;
					border-radius: 5px;
					outline: none;
					border: 1px solid #ccc;
					font-size: 13px;
				}
				.rule-search-but{
					display: inline-block;
					padding:3px 5px;
					margin-left: 10px;
					border-radius: 3px;
					font-size: 14px;
					background-color: #3BA9A9;
					cursor: pointer;
					&:hover{
						color:white;
					}
				}
			}
		}
		.tableContainer{
			.w(100%);
			.h(94%);
			padding-bottom:10px;
			margin-top:15px;
			overflow: hidden;
			.tableBox{
				.w(calc(~"100% + 10px"));
				.h(100%);
				overflow:auto;
				.rule-tab{
					.w(100%);
					text-align:center;
					border-spacing: 0;
					border-collapse: collapse;
					border: 1px solid #ccc;
					tr{
						&:nth-of-type(odd){
							background:#FAFAFA;
						}
						&:hover{
							color: #34b2c9;
						}
						th{
							padding: 7px;
							font-size: 13px;
							color:#fff;
							background:#607d8b;
						}
						td{
							padding:6px;
							font-size: 12px;
						}
					}
				}
			}
			/* 可添加的规则集列表 模块*/
			.addToRuleset-wrap{
				position: absolute;
				z-index: 9;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				margin: auto;
				width: 300px;
				height: 400px;
				font-size: 12px;
				border-radius: 5px;
				box-shadow: 0 0 10px 2px #607D8B;
				background-color: #fff;
				overflow: hidden;
				.ruleset-name{
					padding:10px 0 ;
					color: #fff;
					font-size:13px;
					text-align:center;
					background-color:#009688;
				}
				.addToRuleset-main{
					width: 100%;
					height: calc(~"100% - 72px");
					overflow: hidden;
					.ruleset-items{
						padding:0 15px 20px;
						width:calc(~"100% + 17px");
						height: 100%;
						overflow-y: scroll;
						.ruleset-item{
							position: relative;
							padding: 5px ;
							border-bottom: 1px solid #ccc;
							cursor:pointer;
							&:last-child{
								border: none;
							}
							.icon{
								position:relative;
								float:right;
								top:2px;
							}
						}
					}
				}
				.addRule-confirm{
					width:100%;
					height:35px;
					text-align:center;
					font-size:0px;
					cursor: pointer;
					.confirm-tiem{
						display:inline-block;
						width:50%;
						height:100%;
						line-height:35px;
						font-size:13px;
						&.confirm-cancel{
							color:#999;
							background-color:#f2f2f2;
						}
						&.confirm-add{
							color:#333;
							background-color:#2ab2ca;
						}
						&.confirm-cancel:hover{
							color: #333;
							background-color:#dedede;
						}
						&.confirm-add:hover{
							color: #fff;
						}
					}
				}
			}
		}
		/*  新增规则表格 */
		#rule-wrap{ 
			position: absolute; 
			overflow: hidden;
			z-index: 9; 
			top: 0;
			left: 0;
			padding: 15px;
			width: 100%;
			height: 100%;
			border-radius: 4px;
			background-color: #fff;
			box-shadow: 0 0 10px 3px #ccc;  
			#ruleModule{ 
				overflow: auto;
				width: 100%;
				height: 100%; 
				.ruleModule-items{
					display:flex;
					width:100%; 
					height: 100%;
					border-spacing: 0;
					border-collapse: collapse;
					border: 1px solid #ccc;
					tbody{
						.w(100%);
						.h(100%);
					}
				} 
			} 
			#JSONoutput{ 
				position: absolute; 
				z-index: 2; 
				top: 0;
				left: 0; 
				width: 100%; 
				height: 100%; 
				padding: 15px;
				background-color: #fff;
				overflow: auto; 
			} 
			#ruleModule, #JSONoutput{ 
				ul{ 
					padding-left: 30px;
				}
				li{
					.w(100%);
					.h(25px);
					.l-h(25px);
					padding-left:10px;
				}
				tr{
					display: block;
					.w(100%);
					.h(30px);
					.l-h(30px);
					/*padding: 0px 5px; */
					background-color: white;
					&:hover{
						td,th{
							color:#34b2c9;
						}
					}
					&:nth-child(even){
						background:#eee;
					}
					&:nth-child(odd){
						background:#fff;
					}
					td,th{
						display: inline-block;
						width: 50%;
						height: 100%;
						text-align: left;
						font-size: 12px;
						color:#000;
						background-color: transparent;
						overflow: hidden;
						text-overflow:ellipsis;
						white-space: nowrap;
					}
					&.tr-head{
						.w(100%);
						.h(40px);
						.l-h(40px);
						/*padding: 8px 10px;*/
						background-color: #34b2c9;
						th{
							font-size: 16px;
							text-align:center;
							color:#fff;
							i{
								font-size: 12px;
								color: white;
							}
						}
					}
				}
			}
		} 
	}
</style>