<template>
	<div id="interface">
		<div class="interfaceList-wrap" @click="close($event)">
			<section class="interfaceList-main">
				<span class="interfaceList-close">X</span>
				<h6 class="interfaceList-title">{{interfaceData.title}}</h6>
				<div class="interfaceList-content">
					<ol class="items">
						<li class="item" v-for="row in interfaceData.values" :data-id="row.id">{{row.name}}</li>
					</ol>
					<p class="interfaceList-closing">没有数据了...</p>
				</div>
			</section>
		</div>
	</div>
</template>

<script>
	export default{
		name:'interface',
		data(){
			return{
				interfaceData:{
					title:"接口列表",
					values:[
						{"id":1,"name":"同盾 v1接口"},
						{"id":2,"name":"同盾 v2接口"},
						{"id":3,"name":"同盾 v3接口"},
						{"id":4,"name":"同盾 v4接口"},
						{"id":5,"name":"同盾 v5接口"},
						{"id":6,"name":"同盾 v6接口"},
						{"id":7,"name":"同盾 v7接口"},
						{"id":8,"name":"同盾 v8接口"},
						{"id":9,"name":"同盾 v9接口"},
						{"id":10,"name":"同盾 v10接口"}
					]
				}
			}
		},
		methods:{
			close(e){
				let $className = e.target.className; 
				if($className.indexOf('interfaceList-wrap') > -1 || $className.indexOf('interfaceList-close') > -1){
					this.$emit('upup',{'id':'-1' ,'state':false});
				}else if($className.indexOf('item') > -1){
					this.$emit('upup',{'id':e.target.getAttribute('data-id') ,'state':false});
				}
			}
		}
	}
</script>

<style lang="less" type="text/less">
	
</style>