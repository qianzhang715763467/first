<template>
	<div id="configguration">
		<div class="interfaceList-wrap" @click="close($event)">
			<section class="interfaceList-main">
				<span class="interfaceList-close">X</span>
				<h6 class="interfaceList-title">{{interfaceData.title}}</h6>
				<div class="interfaceList-content">
					<ol class="items">
						<li class="item" v-for="row in interfaceData.values" :data-key="row.key">{{row.val}}</li>
					</ol>
					<p class="interfaceList-closing">没有数据了...</p>
				</div>
			</section>
		</div>
	</div>
</template>

<script>
	export default{
		name:'configguration',
		props:['param'],
		data(){
			return{
				interfaceData:{
					title:"计算字段列表",
					values:this.param
				}
			}
		},
		mounted(){
		},
		methods:{
			close(e){
				let $className = e.target.className; 
				if($className.indexOf('interfaceList-wrap') > -1 || $className.indexOf('interfaceList-close') > -1){
					this.$emit('upup',{
						'key':'',
						'val':'',
						'state':false
					});
				}else if($className.indexOf('item') > -1){
					this.$emit('upup',{
						'key':e.target.getAttribute('data-key'),
						'val':e.target.innerHTML ,
						'state':false
					});
				}
			}
		}
	}
</script>

<style lang="less" type="text/less" scoped>
	
</style>