<template>
	<div id="ruleConfig" v-if="action">
		<!-- headr ber-->
		<header class="addRulesBtnBox">
			<add-button v-show="String(action) == 'true'" :params="{val:'新增规则+',name:'create-rule',action:'create'}" ></add-button>
			<back v-show="String(action) != 'true'" :params="{name:action,modalShow:''}" @edit="editable" ></back>
			<div class="rule-search">
				<input type="text" id="rule-search" placeholder="请输入规则名" value="" v-model="pageData.searchField" @keydown="ruleAction({'action':'search','val':pageData.searchField,'ev':$event})"/>
				<div class="rule-search-but"  @click="ruleAction({'action':'search','val':pageData.searchField})">Search</div>
			</div>
		</header>
		<section class="tableContainer">
			<!-- 规则列表tab -->
			<div class="tableBox">
				<table border="" class="rule-tab">
					<tr>
						<th>操作</th>
						<th v-for="(item,key) in pageData.tableData.thead">{{item}}</th>
					</tr>
					<tr v-for="(row,index) in pageData.tableData.values"  @dblclick="rule_details(row)">
						<td class="rule-tools">
							<rule-toolber v-on:rule-action="ruleAction" :params="{'name':action,'values':row}"></rule-toolber>
						</td>
						<td v-for="(item,key) in pageData.tableData.thead" v-if="key == 'desc'" v-html="row[key]"></td>
						<td v-else>{{row[key]}}</td>
					</tr>
				</table>
			</div>
			<!-- 要添加到的规则集列表  -->
			<div class="addToRuleset-wrap" v-show="pageData.associationRulesetList.ruleSetModuleShow">
				<p class="ruleset-name">规则集名</p>
				<section class="addToRuleset-main">
					<ul class="ruleset-items">
						<li class="ruleset-item" v-for="row in pageData.associationRulesetList.values" @click="pageData.associationRulesetList.selectedRuleSet = row">
							{{row.group_name}}
							<svg-icon id="icon-2xuanzhong" style="color: green;" v-show="row.group_id == pageData.associationRulesetList.selectedRuleSet.group_id"></svg-icon>
						</li>
					</ul>
				</section>
				<p class="addRule-confirm">
					<span class="confirm-cancel confirm-tiem" @click="pageData.associationRulesetList.ruleSetModuleShow = false">取消</span>
					<span class="confirm-add confirm-tiem" @click="ruleAction({'action':''})">确定</span>
				</p>
			</div>
		</section>
		<!-- 规则详情 -->
		<rule-details ref="rulesDetails" v-show="rules_details_show"></rule-details>
		<!-- 新增规则 -->
		<router-view></router-view>
	</div>
</template>

<script type="text/ecmascript-6">
	import RuleToolber		from "./../common/rule-config-modules/rule-toolber.vue"// 规则工具栏
	import RuleDetails		from "./../common/rule-config-modules/rule-details.vue" // 规则详情
	export default {
		name: 'ruleConfig',
		data() {
			return {
				rules_details_show:false,
				'action': false, // （rule | create | details） 进入到当前规则页面的动作，默认从导航"规则"按钮进入。同时也是控制view渲染的的开关。只有当其存在值的时候view才会被渲染。
				"success_count":0,	// 请求成功计数器。（该页面有多个ajax异步请求。为了保证view视图初始化时请求的数据已经返回，所以这里需要个计数器）
				"response": false, // ajax响应状态 （0：失败 | 1：成功）
				'fullPath': false, // 记录当前路径，用于再次点击'规则'导航时对比两次路径是否一致
				'all_rule_data': '', // 全部规则数据
				'all_ruleset_data': '', // 全部规则集数据
				'associated_data': '', // 关联表数据
				'pageData': {
					'searchField': '', // 搜索字段
					'groupAllData': [], // 所有规则集
					'associationRulesetList': { // 添加到规则集列表数据
						ruleSetModuleShow: false,
						selectedRuleSet: '',
						selectedRule_id:null,
						values: []
					},
					'tableData': { // 规则展示table列表数据
						'thead': {
							"id": "规则ID",
							"rule_name": "规则编号",
							"desc": "规则内容",
							"approve_action": "执行动作",
							"threshold": "参数"
						},
						'values': []
					}
				}
			}
		},
		watch:{
			all_rule_data(currentVal,oldval){ 
				if(currentVal.code == '1'){// 请求成功,计数器+1
					this.success_count  += 1;
					this.all_rule_data = currentVal.message;
				}
			},
			all_ruleset_data(currentVal,oldval){
				if(currentVal.code == '1'){// 请求成功,计数器+1
					this.success_count  += 1;
					this.all_ruleset_data = currentVal.message;
				}
			},
			associated_data(currentVal,oldval){
				if(currentVal.code == '1'){// 请求成功,计数器+1
					this.success_count  += 1;
					this.associated_data = currentVal.message;
				}
			},
			response(currentVal,oldVal){// 每次修改完成都要重新初始化数据，做到view及时更新
				alert(currentVal.message);
				this.success_count = 0;
				this.ready();
			},
			$route(currentVal,oldval){// 监听路由的目的： 当前规则页面由其他页面跳转进来，这时候再次点击导航"规则"数据没有初始化
				if(this.fullPath && this.fullPath != currentVal.path ){
					this.success_count = 0;
					this.ready();
				}
			},
			success_count:'formatRuleData'
		},
		mounted(){
			this.ready();
		},
		components:{
			"rule-toolber":RuleToolber,
			"rule-details":RuleDetails
		},
		methods: {
			ready(){
				// （创建规则集||规则集详情）页面跳转进来的，不需要请求关联表&规则集表
				if(this.$route.query.action == 'create' || this.$route.query.action == 'append'){
					this.fullPath = this.$route.fullPath;// 记录当前url
					this.success_count += 2;//直接给请求成功计数器+2
				}else{
					// 关联表全部数据
					this.sendRequest(this,'/rule/ruleGoodsCatagory?select_rows={"ruleset_id":"*"}','associated_data');
					// 规则集全部数据
					this.sendRequest(this,'/ruleset/rulesetGoodsCatagory?select_rows={}','all_ruleset_data');
				}
				// 规则全部数据
				this.sendRequest(this,'/rule/ruleGoodsCatagory?select_rows={}','all_rule_data');
			},
			ruleAction(rule){// 规则动作
				this.pageData.associationRulesetList.ruleSetModuleShow = false;
				switch(rule.action){
					case 'add': // 为规则集增加一个规则
                        if(this.$route.query.action =='create'){
                            // 新增规则到创建页
		                   	var row = JSON.parse(JSON.stringify(rule.val));
		                   		row.enabled = "0";
		                   	this.createData.rawData.values.push(row);
                        }
                        if(this.$route.query.action=='append'){
                        	// 新增规则到详情页
		                   	var row = JSON.parse(JSON.stringify(rule.val));
		                   		row.enabled = "0";
		                   	this.detailData.variableData.values.push(row);
						}
						break;
					case 'remove': // 删除规则
						if(confirm("确定要删除当前规则吗？")){
							// 删除当前规则表数据 ， 删除关联表数据，修改对应规则集数据
							this.sendRequest(this,'/rule/ruleGoodsCatagory?delete_rows={"id":'+ rule.id +'}','response');
						}
						break;
					case 'modify': // 修改规则
                        this.$router.push({
                            path:"/riskStrategy/ruleConfig/create-rule?action=create",
                            query:{action:'modify',id:rule.val.id}
                        });
						break;
					case 'cancel': // 取消增加
                        if(this.$route.query.action =='create'){
                        	for(var i = 0; i < this.createData.rawData.values.length; i++){
		        				if(this.createData.rawData.values[i].id == rule.id){
		        					this.createData.rawData.values.splice(i,1);
		        					break;
		        				}
		        			}
						}else if(this.$route.query.action=='append'){
							for(var i = 0; i < this.detailData.variableData.values.length; i++){
		        				if(this.detailData.variableData.values[i].id == rule.id){
		        					this.detailData.variableData.values.splice(i,1);
		        					break;
		        				}
		        			}
						}
						break;
					case 'search':// 搜索规则
						// ev 属性没有设置 | 设置了ev属性 & 按下了回车键
						if(!rule.ev || rule.ev.keyCode == 13){
							this.search(rule.val);
						}
						break;
					case 'list': // 打开可添加规则集列表
						this.pageData.associationRulesetList.values 	= rule.val.associationRuleset_id;
						this.pageData.associationRulesetList.selectedRule_id = rule.id;
                        this.pageData.associationRulesetList.ruleSetModuleShow	= true;
						break;
					default: // “确认”将规则添加到当前规则集,将对应id 放入规则集表中的关联字段
						// 已选则规则集
						if(this.pageData.associationRulesetList.selectedRuleSet.group_id){
							this.pageData.associationRulesetList.selectedRuleSet.associationRule_id.push(this.pageData.associationRulesetList.selectedRule_id);
							var updata  = {
									"rule_count"	 : this.pageData.associationRulesetList.selectedRuleSet.associationRule_id.length,
									"associative_arr": [
										{	id:this.pageData.associationRulesetList.selectedRule_id,
											state:'0'
										}
									],
									"ruleset_id": this.pageData.associationRulesetList.selectedRuleSet.group_id // 当前规则集id
								};
							this.sendRequest(this,'/rule/ruleGoodsCatagory?update_rows='+JSON.stringify(updata),'response');
						}
						this.pageData.associationRulesetList.selectedRuleSet = "";
						this.pageData.associationRulesetList.ruleSetModuleShow = false;
						break;
				}
			},
			rule_details(row){// 查看规则详细信息
				this.rules_details_show = true;
				for(let i = 0;i < this.$refs.rulesDetails.pageData.values.length; i++){
					let key = this.$refs.rulesDetails.pageData.values[i].field;
					this.$refs.rulesDetails.pageData.values[i].val = row[key];
				}
				// 关联规则集
				let arr = [];
				if(row.correlation_ruleset.length < 1){return this.$refs.rulesDetails.pageData.correlation.values.length = 0;}
				for(let i = 0;i < row.correlation_ruleset.length; i++){
					let obj = row.correlation_ruleset[i];
					for(let j = 0; j < obj.correlation.length; j++){
						if(row.id == obj.correlation[j].rule_id){
							arr.push({
								'ruleset_name'	: obj.group_name,
								'ruleset_id'	: obj.group_id,
								'ruleset_state'	: obj.enabled == '1'? '执行中':(obj.enabled == '2'?'并行测试':'未执行'),
								'current_rules_state': obj.correlation[j].enabled == '1'? '执行中':'未执行'
							});
							break;
						}
					}
				}
				this.$refs.rulesDetails.pageData.correlation.values = arr;
			},
			search(msg){ // 规则搜索
				let currentField= '<i style="background-color:yellow;">'+msg+'</i>';
				for(let i = 0;i < this.pageData.tableData.values.length; i++){
					let row = this.pageData.tableData.values[i];
					// 清空所有标记
					if(row.desc.indexOf('<i style="background-color:yellow;">') > -1){// 当前规则名已经存在查询过的标记？清洗掉标记
						row.desc = row.desc.replace('<i style="background-color:yellow;">',"").replace('</i>',"")
					}
					// 根据规则内容搜索相同字段
					if( row.desc.indexOf(msg)> -1){
						row.desc = row.desc.replace(new RegExp(msg),currentField);
					}
				}
			},
			formatAssociatedData(msg){// 格式化出规则关联的数据
				let associated = {}; // 关联数据，测试
				for(let i = 0;i < msg.length;i++){
					if(associated[msg[i].rule_id]){// 当前key已存在
						associated[msg[i].rule_id].push(msg[i]);
					}else{
						associated[msg[i].rule_id] = [];
						associated[msg[i].rule_id].push(msg[i]);
					}
				}
				return associated;
			},
			formatNotAssociatedData(){// 格式化出规则未关联的数据
				let associated = this.formatAssociatedData(this.associated_data);
				let not_associated = {};// 未关联数据，测试
				let arr = [];
				for(let k in associated){
					not_associated[k] = {
						'associated':associated[k],
						'not_associated':JSON.parse(JSON.stringify(this.all_ruleset_data))
					};
					for(let i = 0; i < associated[k].length; i++){
						arr.push(k);
						arr.push(associated[k][i].group_id)
					}
				}
				for(let i = 1;i < arr.length; i+=2){
					let not_arr = not_associated[arr[i-1]].not_associated;
					for(let n = 0; n < not_arr.length;n++){
						if(arr[i] == not_arr[n].id){
							not_associated[arr[i-1]].not_associated.splice(n,1);
							break;
						}
					}
				}
				return not_associated;
			},
			formatRuleData(val,oldval){ // 格式化规则数据
				if(val == 3){// 所有异步请求都执行完毕
					if(!this.$route.query.action){ // 当前页面从导航进来的，需要格式化
						this.associated_data.sort((a,b) => {return b.group_id - a.group_id});// 关联表排序
						// 测试成功
//						let format_data = this.formatNotAssociatedData();
//						let rule_init_data = JSON.parse(JSON.stringify(this.all_rule_data));// 规则基础数据，测试
//						for(let i = 0;i < rule_init_data.length;i++){
//							let a = [],b = [];
//							// 写入关联数据，操作状态
//							if(format_data[rule_init_data[i].rule_id]){
//								rule_init_data[i].action_modify = false; // 当前规则不可被修改
//								a = format_data[rule_init_data[i].rule_id].associated; 		
//								b = format_data[rule_init_data[i].rule_id].not_associated;
//							}else{// 写入未关联数据，操作状态
//								rule_init_data[i].action_modify = true;// 当前规则可被修改
//								b = JSON.parse(JSON.stringify(this.all_ruleset_data));
//							}
//							rule_init_data[i].associated = a;// 关联数据
//							rule_init_data[i].not_associated = b;// 未关联数据
//						}
//						console.log(rule_init_data)
						
						let rule_new_data  = [];// 格式化后的新数据，测试
						// 格式化出添加到规则集列表所需的所有字段
						for(var i = 0; i < this.all_ruleset_data.length; i++){
							this.pageData.groupAllData[i] = {
								'group_id'			: this.all_ruleset_data[i].id,
								'group_name'		: this.all_ruleset_data[i].ruleset_name,
								'associationRule_id': [],
								'correlation':[],
								'enabled':this.all_ruleset_data[i].enabled,
								'count'				: this.all_ruleset_data[i].rule_count
							};
							for(var n = 0;n < this.associated_data.length; n++){
								if(this.all_ruleset_data[i].id == this.associated_data[n].group_id){
									// 规则集关联规则数据
									this.pageData.groupAllData[i].correlation.push({
										'rule_id':this.associated_data[n].rule_id,
										'enabled':this.associated_data[n].enabled
									})
									this.pageData.groupAllData[i].associationRule_id.push(this.associated_data[n].rule_id);
								}
							}
						};
						for(var i = 0; i < this.all_rule_data.length; i++){// 为每一条规则数据添加一个可添加的规则集数组 associationRuleset_id = []
							let $id = this.all_rule_data[i].id;
							this.all_rule_data[i].correlation_ruleset = [];
							let association = 0;// 用于判断当前规则是否存在关联规则集
							// 所有规则集添加到当前规则的可添加规则集列表中 
							this.all_rule_data[i].associationRuleset_id = JSON.parse(JSON.stringify(this.pageData.groupAllData));
							for(var b = 0; b < this.associated_data.length; b++){// 筛选：关联表中规则id == 当前规则id
								if($id == this.associated_data[b].rule_id){
									association = 1;
									// 二次筛选 ： 关联表中当前规则集id == 规则集列表中规则集的id？ 删除当前规则集
									for(var c = this.pageData.groupAllData.length-1; c > -1; c--){
										//过滤可添加的规则集 （删除"已关联当前规则"的"规则集"）
										if(this.pageData.groupAllData[c].group_id == this.associated_data[b].group_id){
											// 另存 "已关联当前规则"的"规则集",查看规则详情时需要展示在“已包含当前规则的规则集”中
											this.all_rule_data[i].correlation_ruleset.push(this.all_rule_data[i].associationRuleset_id[c]);
											// 可添加的规则集 列表中 删除当前规则集
											this.all_rule_data[i].associationRuleset_id.splice(c,1);
										}
									}
								}
							}
							// 再次过滤可添加的规则集 （只保留“为执行”状态的规则集）
							for(let n = this.all_rule_data[i].associationRuleset_id.length-1; n >= 0; n--){
								if(this.all_rule_data[i].associationRuleset_id[n].enabled > 0){
									this.all_rule_data[i].associationRuleset_id.splice(n,1);
								}
							}
							this.all_rule_data[i].associationRuleset_id.sort((a,b) => {a.rule_id = $id;return a.group_id - b.group_id});
							this.all_rule_data[i].removeBtn = (association == 0 ? true:false); // 当前规则是否可 删除&修改
						}
						this.pageData.tableData.values = this.all_rule_data; 
						this.action = true;
					}else{
						// 获取关联规则id数据
						if(this.$route.query.action == 'create'){
							this.associated_data = this.createData.rawData.correlation_id;
						}else{
							this.associated_data = this.detailData.variableData.correlation_id;
						}
						for(var i = 0; i < this.all_rule_data.length; i++){
							// 区分哪些规则可以被添加到当前规则集
							this.all_rule_data[i].added = (this.associated_data.length == 0 ? true : this.isHave(this.associated_data , this.all_rule_data[i].id) );
						}
						this.pageData.tableData.values = this.all_rule_data; 
						this.action = this.$route.query.action;
					}
					this.success_count = 0;
				}
			}
		}
	}
</script>

<style lang="less" type="text/less">
	@import url("./../../less/common");
	#ruleConfig{ 
		position:relative; 
		padding:15px 10px 15px 15px;
		width:100%;
		height:100%;
		border-radius:5px; 
		background:#fff; 
		.addRulesBtnBox{ 
			width:100%;
			height:6%;
			.rule-search{
				width: 300px;
				float: right;
				font-size: 0;
				text-align: right;
				#rule-search{
					width: 200px;
					padding: 5px;
					border-radius: 5px;
					outline: none;
					border: 1px solid #ccc;
					font-size: 13px;
				}
				.rule-search-but{
					display: inline-block;
					padding:3px 5px;
					margin-left: 10px;
					border-radius: 3px;
					font-size: 14px;
					background-color: #3BA9A9;
					cursor: pointer;
					&:hover{
						color:white;
					}
				}
			}
		}
		.tableContainer{
			.w(100%);
			.h(94%);
			padding-bottom:10px;
			margin-top:15px;
			overflow: hidden;
			.tableBox{
				.w(calc(~"100% + 10px"));
				.h(100%);
				overflow:auto;
				.rule-tab{
					.w(100%);
					text-align:center;
					border-spacing: 0;
					border-collapse: collapse;
					border: 1px solid #ccc;
					tr{
						&:nth-of-type(odd){
							background:#FAFAFA;
						}
						&:hover{
							color: #34b2c9;
						}
						th{
							padding: 7px;
							font-size: 13px;
							color:#fff;
							background:#607d8b;
						}
						td{
							padding:6px;
							font-size: 12px;
						}
					}
				}
			}
			/* 可添加的规则集列表 模块*/
			.addToRuleset-wrap{
				position: absolute;
				z-index: 9;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				margin: auto;
				width: 300px;
				height: 400px;
				font-size: 12px;
				border-radius: 5px;
				box-shadow: 0 0 10px 2px #607D8B;
				background-color: #fff;
				overflow: hidden;
				.ruleset-name{
					padding:10px 0 ;
					color: #fff;
					font-size:13px;
					text-align:center;
					background-color:#009688;
				}
				.addToRuleset-main{
					width: 100%;
					height: calc(~"100% - 72px");
					overflow: hidden;
					.ruleset-items{
						padding:0 15px 20px;
						width:calc(~"100% + 17px");
						height: 100%;
						overflow-y: scroll;
						.ruleset-item{
							position: relative;
							padding: 5px ;
							border-bottom: 1px solid #ccc;
							cursor:pointer;
							&:last-child{
								border: none;
							}
							.icon{
								position:relative;
								float:right;
								top:2px;
							}
						}
					}
				}
				.addRule-confirm{
					width:100%;
					height:35px;
					text-align:center;
					font-size:0px;
					cursor: pointer;
					.confirm-tiem{
						display:inline-block;
						width:50%;
						height:100%;
						line-height:35px;
						font-size:13px;
						&.confirm-cancel{
							color:#999;
							background-color:#f2f2f2;
						}
						&.confirm-add{
							color:#333;
							background-color:#2ab2ca;
						}
						&.confirm-cancel:hover{
							color: #333;
							background-color:#dedede;
						}
						&.confirm-add:hover{
							color: #fff;
						}
					}
				}
			}
		}
		/*  新增规则表格 */
		#rule-wrap{ 
			position: absolute; 
			overflow: hidden;
			z-index: 9; 
			top: 0;
			left: 0;
			padding: 15px;
			width: 100%;
			height: 100%;
			border-radius: 4px;
			background-color: #fff;
			box-shadow: 0 0 10px 3px #ccc;  
			#ruleModule{ 
				overflow: auto;
				width: 100%;
				height: 100%; 
				.ruleModule-items{
					display:flex;
					width:100%; 
					height: 100%;
					border-spacing: 0;
					border-collapse: collapse;
					border: 1px solid #ccc;
					tbody{
						.w(100%);
						.h(100%);
					}
				} 
			} 
			#JSONoutput{ 
				position: absolute; 
				z-index: 2; 
				top: 0;
				left: 0; 
				width: 100%; 
				height: 100%; 
				padding: 15px;
				background-color: #fff;
				overflow: auto; 
			} 
			#ruleModule, #JSONoutput{ 
				ul{ 
					padding-left: 30px;
				}
				li{
					.w(100%);
					.h(25px);
					.l-h(25px);
					padding-left:10px;
				}
				tr{
					display: block;
					.w(100%);
					.h(30px);
					.l-h(30px);
					/*padding: 0px 5px; */
					background-color: white;
					&:hover{
						td,th{
							color:#34b2c9;
						}
					}
					&:nth-child(even){
						background:#eee;
					}
					&:nth-child(odd){
						background:#fff;
					}
					td,th{
						display: inline-block;
						width: 50%;
						height: 100%;
						text-align: left;
						font-size: 12px;
						color:#000;
						background-color: transparent;
						overflow: hidden;
						text-overflow:ellipsis;
						white-space: nowrap;
					}
					&.tr-head{
						.w(100%);
						.h(40px);
						.l-h(40px);
						/*padding: 8px 10px;*/
						background-color: #34b2c9;
						th{
							font-size: 16px;
							text-align:center;
							color:#fff;
							i{
								font-size: 12px;
								color: white;
							}
						}
					}
				}
			}
		} 
	}
</style>