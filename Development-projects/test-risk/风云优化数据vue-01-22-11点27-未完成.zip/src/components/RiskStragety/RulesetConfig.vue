<template>
    <div id="ruleset" v-if="action">
        <div class="addRuleSetBtnBox">
        	<back v-if="pageData.state" :params="{name:pageData.state}"></back>
        	<add-button  v-if="!pageData.state" :params="{val:'新增规则集+',name:'add',action:'createRuleset'}"></add-button>
            <router-link  v-if="pageData.state"  tag="a" class="addEntry-ruleset"
            	:to="{name:pageData.state == 'add-ruleset' ? 'details' : 'add',query:{cRouter:'product',pageName:pageData.state == 'add-ruleset' ? 'details' : 'add',action:'addCorrelation_group'}}" @click.native="addEntryRuleset()">
            	保存
            </router-link>
        </div>
        <div class="ruleSetsBox">
        	<section class="ruleSet-cardSet">
        			<div class="ruleSet-card" v-for="(row,index) in pageData.values">
        				<!-- 产品卡片 -->
	        			<ruleset-card v-on:associated-data="changeAssociatedData" 
	        				:params="{detailsPageName:'ruleset',values:row,filter_associated:pageData.state}" v-show="$route.query.action=='append'||$route.query.action=='create'?isHave(resetsId.useInProducts,row.id):true"></ruleset-card>
        			</div>	
        	</section>
        </div>
    </div>
</template>

<script type="text/ecmascript-6">
	export default{
        name: 'ruleset',
        data(){
            return{
            	action: false,
            	responseStatus:false, // 响应状态
            	pageData:{ // 当前页面所有数据
            		state: false,// 当前页面行为状态（默认|详情|新增）
            		values: [],	// 所有规则集数据
            		rulesetDataToBeAdded:[]// 添加规则集时的暂存数据，点击"保存"时暂存数据会添加到指定的对象中
            	},
                groupProductArr:[],   //规则集_产品关联表里的所有数据
                newCreateId:-1,    //新添加的规则集的id
            }
        },
        mounted(){
        	this.ready();
            this.pageData.rulesetDataToBeAdded.map((item,i)=>{
                this.resetsId.useInProducts.push(item.id);
            });
        },
        watch:{
        	responseStatus(currentVal,oldVal){
        		if(currentVal.code == '1'){
        			this.pageData.values = currentVal.message;
                    this.allData.rulesetsData=currentVal.message;
                    if(this.resetsId.allResetsId.length<=0){    //页面刷新时获取所有规则集的数据集合
                        for(var i=0;i<this.pageData.values.length;i++){   //获取所有规则集Id
                            this.resetsId.allResetsId.push(this.pageData.values[i].id);
                        }
					}else{   //新增规则集时获取所有规则集的数据集合
                        this.resetsId.allResetsId=[];   //初始化所有规则集数据
                        for(var i=0;i<this.pageData.values.length;i++){   //获取所有规则集Id
                            this.resetsId.allResetsId.push(this.pageData.values[i].id);
                        }
                        this.newCreateId=this.resetsId.allResetsId[this.resetsId.allResetsId.length-1];   //获取新增的规则集id
                        this.resetsId.notUseArr.push(this.newCreateId);    //将新增的规则集id放入没有使用规则集的数据集合中
					}
                    this.action = true;
				}
        	},
            groupProductArr(currentVal,oldVal){
                if(currentVal.code==1){
                    this.groupProductArr=currentVal.message;
                    if(this.resetsId.useInProducts<=0){
                        for(var i=0;i<this.groupProductArr.length;i++){   //获取规则集_产品关联表中所有规则集Id
                            this.resetsId.useInProducts.push(this.groupProductArr[i].group_id);
                        }
                    }
                }
            },
            $route(val){
        	    if(val.fullPath=='/riskStrategy/ruleSetConfig'){
                    this.pageData.state=false;
                }
            }
        },
        methods:{
        	ready(){
                this.detailData.allowedReturn = false; // 初始化详情页的全局数据状态
                if(typeof this.$route.query.action == 'string' && this.$route.query.action.length > 0){ // 有传参进来，说明是由其他页面跳转进来添加规则集的
        			this.added = true;
                    this.pageData.state = this.$route.query.action;
                    if(this.pageData.state == 'create'){
                        this.pageData.rulesetDataToBeAdded = JSON.parse(JSON.stringify(this.createData.rawData.values));
                    }else if(this.pageData.state == 'copyCreate'){
                        this.pageData.rulesetDataToBeAdded = JSON.parse(JSON.stringify(this.createData.rawData.values));
                        this.pageData.state=false;
                    }
                    else{
                        this.pageData.rulesetDataToBeAdded = JSON.parse(JSON.stringify(this.detailData.variableData.values));
                    }
        		}
                this.sendRequest(this,'/ruleset/rulesetGoodsCatagory?select_rows={}','responseStatus'); // 全部规则集数据
                this.sendRequest(this,'/product/productGoodsCatagory?select_rows={"product_id":"group_product"}','groupProductArr');   //group_product关联表中的所有数据
                var self=this;
				setTimeout(()=>{
                    var newArr=self.resetsId.allResetsId.concat(self.resetsId.useInProducts);
                    newArr.sort();
                    self.resetsId.notUseArr=JSON.parse(JSON.stringify(self.filterNotSame(newArr)));
                },20)
            },
        	changeAssociatedData(emitVal){ // "增加"|"取消增加"规则集，点击之后的返回整条规则集参数。
        		if(emitVal.action == "add"){// 将"当前规则集参数"暂存
               		var row = JSON.parse(JSON.stringify(emitVal.val));
                    this.pageData.rulesetDataToBeAdded.push(row);
                }else{// 从暂存数据中删除"当前规则集参数"
               		for(var i = 0; i < this.pageData.rulesetDataToBeAdded.length; i++){
        				if(this.pageData.rulesetDataToBeAdded[i].id == emitVal.id){
        					this.pageData.rulesetDataToBeAdded.splice(i,1);
        					break;
        				}
        			}
        		}
        	},
        	addEntryRuleset(){// 提交
        		if(this.pageData.state == 'create'){
        			this.createData.action = 'back';
        			this.createData.rawData.values = JSON.parse(JSON.stringify(this.pageData.rulesetDataToBeAdded));
                }else{
        			this.detailData.variableData.values = JSON.parse(JSON.stringify(this.pageData.rulesetDataToBeAdded));
                    this.removeSameVal(this.resetsId.useInProducts);
                    for(var i=0;i<this.detailData.variableData.values.length;i++){
                        if(!this.isRepetitionVal(this.resetsId.useInProducts,this.detailData.variableData.values[i].id)){
                            this.resetsId.useInProducts.push(this.detailData.variableData.values[i].id);
						}
                    }
                }
        		this.pageData.rulesetDataToBeAdded = [];
        	}
        }
    }
</script>

<style lang="less" type="text/less" scoped>
	@import url("./../../less/common");
    #ruleset{
        position:relative;
        .w(100%);
        .h(100%);
        .b-r(5px);
        box-sizing:border-box;
        background:#fff;
		.noRulesets{
			.w(100%);
			.h(30px);
			.l-h(30px);
			padding-top:30%;
			font-size:18px;
			text-align:center;
			a{
				color:#00bcd4;
				font-weight:bold;
			}
		}
        .addRuleSetBtnBox{
        	position: absolute;
        	z-index: 2;
        	top: 0;
        	left: 0;
            .w(100%);
            background-color: white;
			padding:25px ;
			padding-bottom: 15px;
            .addRulesBtn{
                .w(100px);
                .h(30px);
                .l-h(30px);
                text-align:center;
                border-radius:3px;
                background:@lightGray;
                cursor:pointer;
				&:hover{
					color: #00bcd4;
					box-shadow: 0 0 8px 0px #bdbaba;
				}
            }
            .addEntry-ruleset{
            	position: absolute;
            	top: 9px;
            	right: 10px;
            	width: 80px;
            	height: 30px;
            	line-height: 30px;
            	text-align: center;
            	color: #fff;
            	border-radius: 5px;
				background-color: #009688;
            }
        }
        .ruleSetsBox{
            .h(100%);
            .w(100%);
            overflow: hidden;
            .ruleSet-cardSet{
        		padding: 70px 20px 20px;
            	width: calc(~"100% + 17px");
            	height:100%;
            	overflow-y: auto;
            	.ruleSet-card{
            		position: relative;
            		display: inline-block;
            	}
            }
        }
    }
</style>