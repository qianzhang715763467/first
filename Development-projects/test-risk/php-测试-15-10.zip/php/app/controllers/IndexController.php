<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Hdb\Controllers;

use Phalcon\Mvc\Controller;
use Hdb\Utils\MySqlDB;
use Phalcon\Db;

class IndexController extends Controller {

    public function indexAction(){
    	/*header('Content-Type:text/json;charset=utf-8');
		$str = array
		       (
		          'Name'=>'xiaolou',
		          'Age'=>20
		       );
		
		$jsonencode = json_encode($str);*/
    }

}
