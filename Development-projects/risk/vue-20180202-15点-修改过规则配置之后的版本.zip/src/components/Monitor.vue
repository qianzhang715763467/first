<template>
    <div id="monitor">
        monitor
    </div>
</template>

<script type="text/ecmascript-6">
    export default{
        name:'monitor'
    }
</script>
